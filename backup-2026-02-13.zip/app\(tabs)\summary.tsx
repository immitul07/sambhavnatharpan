import AsyncStorage from "@react-native-async-storage/async-storage";
import * as FileSystem from "expo-file-system/legacy";
import * as Print from "expo-print";
import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useState } from "react";
import { ActivityIndicator, Alert, Platform, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { NIYAM_LIST } from "@/constants/niyams";

const storageSeparator = "::";
const legacyMigrationFlagKey = "legacyProgressMigrationCompletedV1";

function getScopedProgressKey(
  prefix: "aaradhana" | "points" | "submitted",
  accountKey: string,
  dateKey: string,
): string {
  return `${prefix}${storageSeparator}${accountKey}${storageSeparator}${dateKey}`;
}

async function getAccountKeyFromStorage(): Promise<string> {
  const activeAccountKey = (await AsyncStorage.getItem("activeAccountKey")) || "";
  if (activeAccountKey.trim()) {
    return activeAccountKey.trim();
  }

  const accountParts = await AsyncStorage.multiGet(["phoneNumber", "dob"]);
  const phoneNumber = accountParts[0]?.[1]?.trim() || "";
  const dob = accountParts[1]?.[1]?.trim() || "";
  if (!phoneNumber || !dob) {
    return "";
  }

  return `${phoneNumber}|${dob}`;
}

async function migrateLegacyProgressData(accountKey: string): Promise<void> {
  const migrationDone = await AsyncStorage.getItem(legacyMigrationFlagKey);
  if (migrationDone === "true") return;

  const allKeys = await AsyncStorage.getAllKeys();
  const scopedPrefixes = [
    `aaradhana${storageSeparator}${accountKey}${storageSeparator}`,
    `points${storageSeparator}${accountKey}${storageSeparator}`,
    `submitted${storageSeparator}${accountKey}${storageSeparator}`,
  ];
  const hasScopedData = allKeys.some((key) =>
    scopedPrefixes.some((prefix) => key.startsWith(prefix)),
  );
  const legacyKeys = allKeys.filter(
    (key) =>
      key.startsWith("aaradhana-") ||
      key.startsWith("points-") ||
      key.startsWith("submitted-"),
  );
  if (legacyKeys.length === 0) {
    await AsyncStorage.setItem(legacyMigrationFlagKey, "true");
    return;
  }

  if (hasScopedData) {
    await AsyncStorage.multiRemove(legacyKeys);
    await AsyncStorage.setItem(legacyMigrationFlagKey, "true");
    return;
  }

  const legacyEntries = await AsyncStorage.multiGet(legacyKeys);
  const migratedEntries: [string, string][] = [];

  legacyEntries.forEach(([legacyKey, value]) => {
    if (value === null) return;

    if (legacyKey.startsWith("aaradhana-")) {
      const dateKey = legacyKey.replace("aaradhana-", "");
      migratedEntries.push([
        getScopedProgressKey("aaradhana", accountKey, dateKey),
        value,
      ]);
      return;
    }

    if (legacyKey.startsWith("points-")) {
      const dateKey = legacyKey.replace("points-", "");
      migratedEntries.push([getScopedProgressKey("points", accountKey, dateKey), value]);
      return;
    }

    if (legacyKey.startsWith("submitted-")) {
      const dateKey = legacyKey.replace("submitted-", "");
      migratedEntries.push([
        getScopedProgressKey("submitted", accountKey, dateKey),
        value,
      ]);
    }
  });

  if (migratedEntries.length > 0) {
    await AsyncStorage.multiSet(migratedEntries);
  }
  await AsyncStorage.multiRemove(legacyKeys);
  await AsyncStorage.setItem(legacyMigrationFlagKey, "true");
}

async function getPointsForDate(accountKey: string, dateKey: string): Promise<number> {
  const savedPoints = await AsyncStorage.getItem(
    getScopedProgressKey("points", accountKey, dateKey),
  );
  if (savedPoints !== null) {
    const parsed = Number(savedPoints);
    return Number.isNaN(parsed) ? 0 : parsed;
  }

  const savedChecklist = await AsyncStorage.getItem(
    getScopedProgressKey("aaradhana", accountKey, dateKey),
  );
  if (!savedChecklist) {
    return 0;
  }

  try {
    const parsedChecklist = JSON.parse(savedChecklist) as Record<string, boolean>;
    return NIYAM_LIST.reduce((sum, item) => {
      return sum + (parsedChecklist[item.key] ? item.points : 0);
    }, 0);
  } catch {
    return 0;
  }
}

async function getAllDateKeysWithData(accountKey: string): Promise<string[]> {
  const keys = await AsyncStorage.getAllKeys();
  const dateKeys = new Set<string>();
  const pointsPrefix = `points${storageSeparator}${accountKey}${storageSeparator}`;
  const checklistPrefix = `aaradhana${storageSeparator}${accountKey}${storageSeparator}`;

  keys.forEach((key) => {
    if (key.startsWith(pointsPrefix)) {
      dateKeys.add(key.slice(pointsPrefix.length));
    }
    if (key.startsWith(checklistPrefix)) {
      dateKeys.add(key.slice(checklistPrefix.length));
    }
  });

  return Array.from(dateKeys);
}

async function getAllTimeTotal(accountKey: string): Promise<number> {
  const dateKeys = await getAllDateKeysWithData(accountKey);
  if (dateKeys.length === 0) {
    return 0;
  }

  const values = await Promise.all(
    dateKeys.map((dateKey) => getPointsForDate(accountKey, dateKey)),
  );
  return values.reduce((sum, points) => sum + points, 0);
}

async function getNiyamProgress(accountKey: string): Promise<{
  totalDays: number;
  progress: Record<string, number>;
}> {
  const keys = await AsyncStorage.getAllKeys();
  const checklistPrefix = `aaradhana${storageSeparator}${accountKey}${storageSeparator}`;
  const checklistKeys = keys.filter((key) => key.startsWith(checklistPrefix));
  const progress: Record<string, number> = {};
  NIYAM_LIST.forEach((item) => {
    progress[item.key] = 0;
  });

  if (checklistKeys.length === 0) {
    return { totalDays: 0, progress };
  }

  const entries = await AsyncStorage.multiGet(checklistKeys);
  entries.forEach(([, value]) => {
    if (!value) return;
    try {
      const parsed = JSON.parse(value) as Record<string, boolean>;
      NIYAM_LIST.forEach((item) => {
        if (parsed[item.key]) {
          progress[item.key] += 1;
        }
      });
    } catch {
      // Ignore malformed checklist entries.
    }
  });

  return { totalDays: checklistKeys.length, progress };
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

type ExportUserInfo = {
  name: string;
  phone: string;
};

function sanitizeFileName(value: string): string {
  return value.replace(/[<>:"/\\|?*\u0000-\u001F]/g, "").replace(/\s+/g, " ").trim();
}

async function getExportUserInfo(accountKey: string): Promise<ExportUserInfo> {
  const parts = await AsyncStorage.multiGet(["userName", "phoneNumber", "accounts"]);
  const fallbackName = parts[0]?.[1]?.trim() || "User";
  const fallbackPhone = parts[1]?.[1]?.trim() || "";
  const rawAccounts = parts[2]?.[1] || "";

  if (!rawAccounts || !accountKey) {
    return { name: fallbackName, phone: fallbackPhone };
  }

  try {
    const accounts = JSON.parse(rawAccounts) as {
      fullName?: string;
      firstName?: string;
      middleName?: string;
      lastName?: string;
      phoneNumber?: string;
      dob?: string;
    }[];
    const current = accounts.find((acc) => {
      const phone = (acc.phoneNumber || "").replace(/\D/g, "");
      const dob = (acc.dob || "").trim();
      return `${phone}|${dob}` === accountKey;
    });

    if (!current) {
      return { name: fallbackName, phone: fallbackPhone };
    }

    const resolvedName =
      current.fullName?.trim() ||
      `${current.firstName || ""} ${current.middleName || ""} ${current.lastName || ""}`
        .replace(/\s+/g, " ")
        .trim() ||
      fallbackName;

    const resolvedPhone = current.phoneNumber?.trim() || fallbackPhone;
    return { name: resolvedName, phone: resolvedPhone };
  } catch {
    return { name: fallbackName, phone: fallbackPhone };
  }
}

function buildMonthSection(year: number, monthIndex: number, user: ExportUserInfo, isLastPage: boolean): string {
  const monthName = new Date(year, monthIndex, 1).toLocaleString("en-US", { month: "long" });
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
  const dayHeaders = Array.from({ length: daysInMonth }, (_, i) => `<th>${i + 1}</th>`).join("");
  const dayCells = Array.from({ length: daysInMonth }, () => "<td></td>").join("");
  const rows = NIYAM_LIST.map((item, index) => {
    return `<tr>
      <td class="sr">${index + 1}</td>
      <td class="niyam">
        <div class="gu">${escapeHtml(item.gu)}</div>
        <div class="en">${escapeHtml(item.en)}</div>
      </td>
      ${dayCells}
    </tr>`;
  }).join("");

  return `<section class="page${isLastPage ? "" : " with-break"}">
    <div class="header">
      <div>
        <h1>Daily Niyam</h1>
        <p>Month: ${monthName} ${year}</p>
      </div>
      <div class="user-meta">
        <div><strong>Name:</strong> ${escapeHtml(user.name)}</div>
        <div><strong>Phone:</strong> ${escapeHtml(user.phone || "-")}</div>
      </div>
    </div>
    <table>
      <thead>
        <tr>
          <th class="sr">Sr</th>
          <th class="niyam-head">Niyam</th>
          ${dayHeaders}
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  </section>`;
}

function buildHardcopyTemplateHtml(user: ExportUserInfo): string {
  const sections: string[] = [];
  for (let monthIndex = 2; monthIndex <= 11; monthIndex += 1) {
    sections.push(buildMonthSection(2026, monthIndex, user, monthIndex === 11));
  }

  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <style>
      @page { size: A4 portrait; margin: 2mm; }
      body { font-family: Arial, sans-serif; margin: 0; color: #111827; }
      .page { width: 100%; }
      .with-break { page-break-after: always; }
      .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 2px; }
      h1 { margin: 0; font-size: 11px; }
      p { margin: 1px 0 0; font-size: 7px; color: #374151; }
      .user-meta { text-align: right; font-size: 7px; line-height: 1.1; }
      table { border-collapse: collapse; width: 100%; table-layout: fixed; }
      th, td { border: 1px solid #cbd5e1; text-align: center; padding: 0.5px; font-size: 5px; height: 8px; line-height: 1; }
      th { background: #f1f5f9; font-weight: 700; }
      .sr { width: 12px; }
      .niyam-head, .niyam { width: 98px; text-align: left; }
      .niyam { padding: 0.8px 1.6px; }
      .gu { font-size: 6px; line-height: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .en { font-size: 5px; color: #4b5563; line-height: 1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    </style>
  </head>
  <body>${sections.join("")}</body>
</html>`;
}

export default function SummaryScreen() {
  const router = useRouter();
  const [showMenu, setShowMenu] = useState(false);
  const [loading, setLoading] = useState(true);
  const [totalPoints, setTotalPoints] = useState(0);
  const [totalDaysTracked, setTotalDaysTracked] = useState(0);
  const [niyamProgress, setNiyamProgress] = useState<Record<string, number>>({});
  const [sortBy, setSortBy] = useState<"serial" | "days" | "alpha" | "points">("days");

  const exportHardcopyPdf = async () => {
    try {
      const accountKey = await getAccountKeyFromStorage();
      const user = await getExportUserInfo(accountKey);
      const html = buildHardcopyTemplateHtml(user);
      const { uri } = await Print.printToFileAsync({
        html,
        width: 842,
        height: 1191,
      });
      const safeName = sanitizeFileName(user.name || "User");
      const outputFileName = `Daily Niyam - (${safeName}).pdf`;

      if (Platform.OS === "android") {
        const downloadsUri = FileSystem.StorageAccessFramework.getUriForDirectoryInRoot("Download");
        let permission =
          await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync(downloadsUri);

        if (!permission.granted) {
          permission = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
        }

        if (!permission.granted) {
          Alert.alert(
            "Permission required",
            "Android blocked the selected folder. Please choose a writable folder in Internal storage (preferably Download).",
          );
          return;
        }
        const selectedUri = permission.directoryUri || "";

        const base64 = await FileSystem.readAsStringAsync(uri, {
          encoding: FileSystem.EncodingType.Base64,
        });

        let fileUri = "";
        try {
          fileUri = await FileSystem.StorageAccessFramework.createFileAsync(
            selectedUri,
            outputFileName,
            "application/pdf",
          );
        } catch {
          fileUri = await FileSystem.StorageAccessFramework.createFileAsync(
            selectedUri,
            `Daily Niyam - (${safeName})-${Date.now()}.pdf`,
            "application/pdf",
          );
        }

        await FileSystem.writeAsStringAsync(fileUri, base64, {
          encoding: FileSystem.EncodingType.Base64,
        });
        Alert.alert("Download complete", `${outputFileName} saved in Downloads folder.`);
        return;
      }

      const destination = `${FileSystem.documentDirectory}${outputFileName}`;
      await FileSystem.copyAsync({ from: uri, to: destination });
      Alert.alert("Saved", `${outputFileName} saved in app files (iOS/web fallback).`);
    } catch {
      Alert.alert("Export failed", "Could not generate hardcopy PDF.");
    }
  };

  const logout = async () => {
    await AsyncStorage.multiRemove([
      "firstName",
      "middleName",
      "lastName",
      "gender",
      "userName",
      "dateOfBirth",
      "dob",
      "hotiNo",
      "villageCode",
      "profilePhoto",
      "photoUri",
      "phoneNumber",
      "address",
      "activeAccountKey",
      "adminSession",
      "adminSelectedAccountKey",
    ]);
    router.replace("/login");
  };

  const loadSummary = useCallback(async () => {
    setLoading(true);
    const accountKey = await getAccountKeyFromStorage();
    if (!accountKey) {
      setLoading(false);
      router.replace("/login");
      return;
    }

    await migrateLegacyProgressData(accountKey);
    const [total, niyamData] = await Promise.all([
      getAllTimeTotal(accountKey),
      getNiyamProgress(accountKey),
    ]);
    setTotalPoints(total);
    setTotalDaysTracked(niyamData.totalDays);
    setNiyamProgress(niyamData.progress);
    setLoading(false);
  }, [router]);

  useFocusEffect(
    useCallback(() => {
      loadSummary();
    }, [loadSummary]),
  );

  const sortedNiyams = [...NIYAM_LIST].sort((a, b) => {
    if (sortBy === "serial") {
      return NIYAM_LIST.findIndex((item) => item.key === a.key) - NIYAM_LIST.findIndex((item) => item.key === b.key);
    }

    const aDays = niyamProgress[a.key] || 0;
    const bDays = niyamProgress[b.key] || 0;
    const aTotalPoints = aDays * a.points;
    const bTotalPoints = bDays * b.points;

    if (sortBy === "alpha") {
      return a.en.localeCompare(b.en);
    }
    if (sortBy === "points") {
      if (bTotalPoints !== aTotalPoints) return bTotalPoints - aTotalPoints;
      return bDays - aDays;
    }
    if (bDays !== aDays) return bDays - aDays;
    return a.en.localeCompare(b.en);
  });

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#f8fafc" }} edges={["top"]}>
      <ScrollView contentContainerStyle={{ flexGrow: 1, padding: 20, paddingTop: 10, paddingBottom: 24 }}>
        <View style={{ position: "relative", marginBottom: 14 }}>
          <Text style={{ fontSize: 22, textAlign: "center", color: "#0f172a" }}>
            Summary / સારાંશ
          </Text>
          <TouchableOpacity
            onPress={() => setShowMenu((prev) => !prev)}
            style={{ position: "absolute", right: 0, top: 0, padding: 4 }}
          >
            <Text style={{ fontSize: 26 }}>☰</Text>
          </TouchableOpacity>
          {showMenu && (
            <View
              style={{
                position: "absolute",
                right: 0,
                top: 34,
                backgroundColor: "#f8fafc",
                borderWidth: 1,
                borderColor: "#ddd",
                borderRadius: 8,
                paddingVertical: 6,
                width: 150,
                zIndex: 10,
              }}
            >
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Home</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)/summary");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Summary</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)/leaderboard");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Leaderboard</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/literature");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Literature Files</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)/profile");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Profile</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  logout();
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Logout</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        <Text style={{ textAlign: "center", color: "#6b7280", marginBottom: 24 }}>
          Total points and niyam-wise progress.
        </Text>
        <TouchableOpacity
          onPress={exportHardcopyPdf}
          style={{
            marginBottom: 16,
            alignSelf: "center",
            borderWidth: 1,
            borderColor: "#1e293b",
            borderRadius: 10,
            paddingHorizontal: 14,
            paddingVertical: 10,
            backgroundColor: "#fff",
          }}
        >
          <Text style={{ color: "#1e293b", fontWeight: "600" }}>Download Blank Copy</Text>
        </TouchableOpacity>

        {loading ? (
          <View style={{ marginTop: 40, alignItems: "center" }}>
            <ActivityIndicator size="large" />
            <Text style={{ marginTop: 12, color: "#666" }}>Loading summary...</Text>
          </View>
        ) : (
          <View style={{ gap: 12 }}>
            <View
              style={{
                borderWidth: 1,
                borderColor: "#dbe3ee",
                borderRadius: 14,
                padding: 16,
                backgroundColor: "#f8fafc",
              }}
            >
              <Text style={{ fontSize: 16, marginBottom: 4 }}>Total Points</Text>
              <Text style={{ color: "#666", marginBottom: 8 }}>Total Points</Text>
              <Text style={{ fontSize: 30, fontWeight: "700", color: "#0f172a" }}>
                {totalPoints}
              </Text>
            </View>

            <View
              style={{
                borderWidth: 1,
                borderColor: "#dbe3ee",
                borderRadius: 14,
                padding: 16,
                backgroundColor: "#f8fafc",
              }}
            >
              <Text style={{ fontSize: 16, marginBottom: 8 }}>
                નિયમ પ્રગતિ (Niyam Progress)
              </Text>

              <View style={{ flexDirection: "row", gap: 8, marginBottom: 10 }}>
                <TouchableOpacity
                  onPress={() => setSortBy("serial")}
                  style={{
                    borderWidth: 1,
                    borderColor: "#cbd5e1",
                    borderRadius: 8,
                    paddingHorizontal: 10,
                    paddingVertical: 6,
                    backgroundColor: sortBy === "serial" ? "#1e293b" : "#fff",
                  }}
                >
                  <Text style={{ color: sortBy === "serial" ? "#fff" : "#1e293b" }}>Serial No.</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setSortBy("days")}
                  style={{
                    borderWidth: 1,
                    borderColor: "#cbd5e1",
                    borderRadius: 8,
                    paddingHorizontal: 10,
                    paddingVertical: 6,
                    backgroundColor: sortBy === "days" ? "#1e293b" : "#fff",
                  }}
                >
                  <Text style={{ color: sortBy === "days" ? "#fff" : "#1e293b" }}>Days</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setSortBy("alpha")}
                  style={{
                    borderWidth: 1,
                    borderColor: "#cbd5e1",
                    borderRadius: 8,
                    paddingHorizontal: 10,
                    paddingVertical: 6,
                    backgroundColor: sortBy === "alpha" ? "#1e293b" : "#fff",
                  }}
                >
                  <Text style={{ color: sortBy === "alpha" ? "#fff" : "#1e293b" }}>A-Z</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setSortBy("points")}
                  style={{
                    borderWidth: 1,
                    borderColor: "#cbd5e1",
                    borderRadius: 8,
                    paddingHorizontal: 10,
                    paddingVertical: 6,
                    backgroundColor: sortBy === "points" ? "#1e293b" : "#fff",
                  }}
                >
                  <Text style={{ color: sortBy === "points" ? "#fff" : "#1e293b" }}>
                    Max Points
                  </Text>
                </TouchableOpacity>
              </View>

              <View
                style={{
                  borderWidth: 1,
                  borderColor: "#dbe3ee",
                  borderRadius: 10,
                  overflow: "hidden",
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    backgroundColor: "#eef2f9",
                    paddingVertical: 10,
                    paddingHorizontal: 8,
                  }}
                >
                  <Text style={{ width: "10%", fontWeight: "700" }}>Sr</Text>
                  <Text style={{ width: "45%", fontWeight: "700" }}>Niyam</Text>
                  <Text style={{ width: "20%", fontWeight: "700", textAlign: "center" }}>
                    Days
                  </Text>
                  <Text style={{ width: "25%", fontWeight: "700", textAlign: "center" }}>
                    Total Pts
                  </Text>
                </View>

                {sortedNiyams.map((item, index) => {
                  const doneDays = niyamProgress[item.key] || 0;
                  const earnedPoints = doneDays * item.points;
                  return (
                    <View
                      key={item.key}
                      style={{
                        flexDirection: "row",
                        alignItems: "center",
                        paddingVertical: 10,
                        paddingHorizontal: 8,
                        borderTopWidth: 1,
                        borderTopColor: "#eef2f9",
                      }}
                    >
                      <Text style={{ width: "10%" }}>{index + 1}</Text>
                      <View style={{ width: "45%" }}>
                        <Text style={{ fontSize: 15 }}>{item.gu}</Text>
                        <Text style={{ color: "#666", fontSize: 11 }}>{item.en}</Text>
                      </View>
                      <Text style={{ width: "20%", textAlign: "center" }}>
                        {doneDays}/{totalDaysTracked}
                      </Text>
                      <Text style={{ width: "25%", textAlign: "center", fontWeight: "600" }}>
                        {earnedPoints}
                      </Text>
                    </View>
                  );
                })}
              </View>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

