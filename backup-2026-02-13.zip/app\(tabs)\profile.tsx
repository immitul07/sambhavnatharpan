import AsyncStorage from "@react-native-async-storage/async-storage";
import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useState } from "react";
import { Image, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

function calculateAgeFromDob(dob: string): number | null {
  const parsed = new Date(dob);
  if (Number.isNaN(parsed.getTime())) {
    return null;
  }

  const today = new Date();
  let age = today.getFullYear() - parsed.getFullYear();
  const monthDiff = today.getMonth() - parsed.getMonth();
  const dayDiff = today.getDate() - parsed.getDate();

  if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) {
    age -= 1;
  }
  return age < 0 ? null : age;
}

function getAgeCategory(age: number | null): string {
  if (age === null) return "Unknown";
  if (age <= 12) return "Child";
  if (age <= 17) return "Teen";
  if (age <= 25) return "Youth";
  if (age <= 59) return "Adult";
  return "Senior";
}

export default function ProfileScreen() {
  const router = useRouter();
  const [showMenu, setShowMenu] = useState(false);
  const [name, setName] = useState("Not set");
  const [gender, setGender] = useState("Not set");
  const [dob, setDob] = useState("Not set");
  const [photoUri, setPhotoUri] = useState<string | null>(null);
  const [hotiNo, setHotiNo] = useState("Not set");
  const [phoneNumber, setPhoneNumber] = useState("Not set");
  const [address, setAddress] = useState("Not set");

  const logout = async () => {
    await AsyncStorage.multiRemove([
      "firstName",
      "middleName",
      "lastName",
      "gender",
      "userName",
      "dateOfBirth",
      "dob",
      "hotiNo",
      "villageCode",
      "profilePhoto",
      "photoUri",
      "phoneNumber",
      "address",
      "activeAccountKey",
      "adminSession",
      "adminSelectedAccountKey",
    ]);
    router.replace("/login");
  };

  const loadProfile = useCallback(async () => {
    const savedFirstName = await AsyncStorage.getItem("firstName");
    const savedMiddleName = await AsyncStorage.getItem("middleName");
    const savedLastName = await AsyncStorage.getItem("lastName");
    const fullNameFromParts = [savedFirstName, savedMiddleName, savedLastName]
      .filter(Boolean)
      .join(" ");
    const savedName = await AsyncStorage.getItem("userName");
    const savedGender = await AsyncStorage.getItem("gender");
    const savedDob =
      (await AsyncStorage.getItem("dateOfBirth")) ||
      (await AsyncStorage.getItem("dob"));
    const savedPhoto =
      (await AsyncStorage.getItem("profilePhoto")) ||
      (await AsyncStorage.getItem("photoUri"));
    const savedHoti =
      (await AsyncStorage.getItem("hotiNo")) ||
      (await AsyncStorage.getItem("villageCode"));
    const savedPhone = await AsyncStorage.getItem("phoneNumber");
    const savedAddress = await AsyncStorage.getItem("address");

    setName(fullNameFromParts || savedName || "Not set");
    setGender(savedGender || "Not set");
    setDob(savedDob || "Not set");
    const normalizedPhoto = (savedPhoto || "").trim();
    setPhotoUri(
      normalizedPhoto &&
        normalizedPhoto !== "null" &&
        normalizedPhoto !== "undefined"
        ? normalizedPhoto
        : null,
    );
    setHotiNo(savedHoti || "Not set");
    setPhoneNumber(savedPhone || "Not set");
    setAddress(savedAddress || "Not set");
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadProfile();
    }, [loadProfile]),
  );

  const age = dob !== "Not set" ? calculateAgeFromDob(dob) : null;
  const ageCategory = getAgeCategory(age);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#f8fafc" }} edges={["top"]}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 10, paddingBottom: 24 }}>
        <View style={{ position: "relative", marginBottom: 18 }}>
          <Text style={{ fontSize: 22, textAlign: "center", color: "#0f172a" }}>Profile</Text>
          <TouchableOpacity
            onPress={() => setShowMenu((prev) => !prev)}
            style={{ position: "absolute", right: 0, top: 0, padding: 4 }}
          >
            <Text style={{ fontSize: 26 }}>{"\u2630"}</Text>
          </TouchableOpacity>
          {showMenu && (
            <View
              style={{
                position: "absolute",
                right: 0,
                top: 34,
                backgroundColor: "#f8fafc",
                borderWidth: 1,
                borderColor: "#ddd",
                borderRadius: 8,
                paddingVertical: 6,
                width: 150,
                zIndex: 10,
              }}
            >
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Home</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)/summary");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Summary</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)/leaderboard");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Leaderboard</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/literature");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Literature Files</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)/profile");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Profile</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  logout();
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Logout</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        <View
          style={{
            alignItems: "center",
            marginBottom: 20,
            borderWidth: 1,
            borderColor: "#dbe3ee",
            borderRadius: 14,
            padding: 16,
            backgroundColor: "#f8fafc",
          }}
        >
          {photoUri ? (
            <Image
              source={{ uri: photoUri }}
              style={{ width: 120, height: 120, borderRadius: 60, marginBottom: 12 }}
            />
          ) : (
            <View
              style={{
                width: 120,
                height: 120,
                borderRadius: 60,
                marginBottom: 12,
                backgroundColor: "#dbe3ee",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Text style={{ color: "#6b7280" }}>No Photo</Text>
            </View>
          )}
          <Text style={{ color: "#6b7280" }}>Photo</Text>
        </View>

        <View
          style={{
            borderWidth: 1,
            borderColor: "#dbe3ee",
            borderRadius: 14,
            padding: 16,
            backgroundColor: "#f8fafc",
            gap: 12,
          }}
        >
          <View>
            <Text style={{ color: "#6b7280", marginBottom: 4 }}>Name</Text>
            <Text style={{ fontSize: 18 }}>{name}</Text>
          </View>

          <View>
            <Text style={{ color: "#6b7280", marginBottom: 4 }}>Gender</Text>
            <Text style={{ fontSize: 18 }}>{gender}</Text>
          </View>

          <View>
            <Text style={{ color: "#6b7280", marginBottom: 4 }}>Date of Birth</Text>
            <Text style={{ fontSize: 18 }}>{dob}</Text>
          </View>

          <View>
            <Text style={{ color: "#6b7280", marginBottom: 4 }}>Age Category</Text>
            <Text style={{ fontSize: 18 }}>{ageCategory}</Text>
          </View>

          <View>
            <Text style={{ color: "#6b7280", marginBottom: 4 }}>Hoti No.</Text>
            <Text style={{ fontSize: 18 }}>{hotiNo}</Text>
          </View>

          <View>
            <Text style={{ color: "#6b7280", marginBottom: 4 }}>Phone Number</Text>
            <Text style={{ fontSize: 18 }}>{phoneNumber}</Text>
          </View>

          <View>
            <Text style={{ color: "#6b7280", marginBottom: 4 }}>Address</Text>
            <Text style={{ fontSize: 18 }}>{address}</Text>
          </View>
        </View>

        <TouchableOpacity
          onPress={() => router.push("/register?mode=edit")}
          style={{
            marginTop: 14,
            borderWidth: 1,
            borderColor: "#ea580c",
            borderRadius: 12,
            padding: 12,
          }}
        >
          <Text style={{ textAlign: "center" }}>Edit Details</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}



