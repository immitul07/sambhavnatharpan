import AsyncStorage from "@react-native-async-storage/async-storage";
import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useMemo, useState } from "react";
import { ActivityIndicator, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

type StoredAccount = {
  firstName: string;
  middleName: string;
  lastName: string;
  fullName: string;
  dob: string;
  phoneNumber: string;
  hotiNo?: string;
};

type LeaderboardRow = {
  accountKey: string;
  name: string;
  totalPoints: number;
};

const storageSeparator = "::";

function normalizePhone(value: string): string {
  return value.replace(/\D/g, "");
}

function getAccountKey(phoneNumber: string, dob: string): string {
  return `${normalizePhone(phoneNumber)}|${dob.trim()}`;
}

function getScopedProgressKey(
  prefix: "aaradhana" | "points" | "submitted",
  accountKey: string,
  dateKey: string,
): string {
  return `${prefix}${storageSeparator}${accountKey}${storageSeparator}${dateKey}`;
}

async function getAccountKeyFromStorage(): Promise<string> {
  const activeAccountKey = (await AsyncStorage.getItem("activeAccountKey")) || "";
  if (activeAccountKey.trim()) {
    return activeAccountKey.trim();
  }

  const accountParts = await AsyncStorage.multiGet(["phoneNumber", "dob"]);
  const phoneNumber = accountParts[0]?.[1]?.trim() || "";
  const dob = accountParts[1]?.[1]?.trim() || "";
  if (!phoneNumber || !dob) {
    return "";
  }

  return `${phoneNumber}|${dob}`;
}

async function getAllDateKeysWithData(accountKey: string): Promise<string[]> {
  const keys = await AsyncStorage.getAllKeys();
  const dateKeys = new Set<string>();
  const pointsPrefix = `points${storageSeparator}${accountKey}${storageSeparator}`;
  const checklistPrefix = `aaradhana${storageSeparator}${accountKey}${storageSeparator}`;

  keys.forEach((key) => {
    if (key.startsWith(pointsPrefix)) dateKeys.add(key.slice(pointsPrefix.length));
    if (key.startsWith(checklistPrefix)) dateKeys.add(key.slice(checklistPrefix.length));
  });

  return Array.from(dateKeys);
}

async function getPointsForDate(accountKey: string, dateKey: string): Promise<number> {
  const savedPoints = await AsyncStorage.getItem(
    getScopedProgressKey("points", accountKey, dateKey),
  );
  if (savedPoints === null) {
    return 0;
  }
  const parsed = Number(savedPoints);
  return Number.isNaN(parsed) ? 0 : parsed;
}

async function getAllTimeTotal(accountKey: string): Promise<number> {
  const dateKeys = await getAllDateKeysWithData(accountKey);
  if (dateKeys.length === 0) {
    return 0;
  }

  const values = await Promise.all(
    dateKeys.map((dateKey) => getPointsForDate(accountKey, dateKey)),
  );
  return values.reduce((sum, points) => sum + points, 0);
}

export default function LeaderboardScreen() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [hoti, setHoti] = useState("");
  const [rows, setRows] = useState<LeaderboardRow[]>([]);

  const sortedRows = useMemo(
    () => [...rows].sort((a, b) => b.totalPoints - a.totalPoints),
    [rows],
  );

  const loadLeaderboard = useCallback(async () => {
    setLoading(true);

    const accountKey = await getAccountKeyFromStorage();
    if (!accountKey) {
      setLoading(false);
      router.replace("/login");
      return;
    }

    const rawAccounts = await AsyncStorage.getItem("accounts");
    const accounts: StoredAccount[] = rawAccounts ? JSON.parse(rawAccounts) : [];
    const activeAccount = accounts.find(
      (account) => getAccountKey(account.phoneNumber, account.dob) === accountKey,
    );

    const selectedHoti =
      activeAccount?.hotiNo?.trim() ||
      (await AsyncStorage.getItem("villageCode"))?.trim() ||
      (await AsyncStorage.getItem("hotiNo"))?.trim() ||
      "";

    setHoti(selectedHoti);

    if (!selectedHoti) {
      setRows([]);
      setLoading(false);
      return;
    }

    const sameHotiAccounts = accounts.filter(
      (account) => (account.hotiNo || "").trim() === selectedHoti,
    );

    const leaderboardRows = await Promise.all(
      sameHotiAccounts.map(async (account) => {
        const rowKey = getAccountKey(account.phoneNumber, account.dob);
        const totalPoints = await getAllTimeTotal(rowKey);
        return {
          accountKey: rowKey,
          name:
            account.fullName ||
            `${account.firstName} ${account.middleName} ${account.lastName}`.replace(/\s+/g, " ").trim(),
          totalPoints,
        };
      }),
    );

    setRows(leaderboardRows);
    setLoading(false);
  }, [router]);

  useFocusEffect(
    useCallback(() => {
      loadLeaderboard();
    }, [loadLeaderboard]),
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#f8fafc" }} edges={["top"]}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 10, paddingBottom: 24 }}>
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: 12,
          }}
        >
          <Text style={{ fontSize: 22, color: "#0f172a" }}>Leaderboard</Text>
          <TouchableOpacity
            onPress={() => router.back()}
            style={{
              borderWidth: 1,
              borderColor: "#cbd5e1",
              borderRadius: 10,
              paddingVertical: 8,
              paddingHorizontal: 12,
            }}
          >
            <Text>Back</Text>
          </TouchableOpacity>
        </View>

        <Text style={{ color: "#6b7280", marginBottom: 12 }}>
          {hoti ? `Hoti: ${hoti}` : "Hoti not found for current account."}
        </Text>

        {loading ? (
          <View style={{ marginTop: 40, alignItems: "center" }}>
            <ActivityIndicator size="large" />
            <Text style={{ marginTop: 12, color: "#666" }}>Loading leaderboard...</Text>
          </View>
        ) : sortedRows.length === 0 ? (
          <Text style={{ color: "#6b7280" }}>No users found for this hoti.</Text>
        ) : (
          <View
            style={{
              borderWidth: 1,
              borderColor: "#dbe3ee",
              borderRadius: 12,
              overflow: "hidden",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                backgroundColor: "#eef2f9",
                paddingVertical: 10,
                paddingHorizontal: 8,
              }}
            >
              <Text style={{ width: "18%", fontWeight: "700" }}>Sr.No</Text>
              <Text style={{ width: "57%", fontWeight: "700" }}>Name</Text>
              <Text style={{ width: "25%", fontWeight: "700", textAlign: "right" }}>Points</Text>
            </View>

            {sortedRows.map((item, index) => (
              <View
                key={item.accountKey}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingVertical: 10,
                  paddingHorizontal: 8,
                  borderTopWidth: 1,
                  borderTopColor: "#eef2f9",
                }}
              >
                <Text style={{ width: "18%" }}>{index + 1}</Text>
                <Text style={{ width: "57%", color: "#0f172a" }}>{item.name}</Text>
                <Text style={{ width: "25%", textAlign: "right", fontWeight: "700" }}>
                  {item.totalPoints}
                </Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

