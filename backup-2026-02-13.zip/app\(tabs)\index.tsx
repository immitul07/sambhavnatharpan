import AsyncStorage from "@react-native-async-storage/async-storage";
import { useFocusEffect, useRouter } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { Alert, ScrollView, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { NIYAM_LIST } from "@/constants/niyams";
import { upsertCloudProgress } from "@/lib/cloud-progress";

function getLocalDateKey(date: Date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

const storageSeparator = "::";
const legacyMigrationFlagKey = "legacyProgressMigrationCompletedV1";

function getScopedProgressKey(
  prefix: "aaradhana" | "points" | "submitted",
  accountKey: string,
  dateKey: string,
): string {
  return `${prefix}${storageSeparator}${accountKey}${storageSeparator}${dateKey}`;
}

async function getAccountKeyFromStorage(): Promise<string> {
  const activeAccountKey = (await AsyncStorage.getItem("activeAccountKey")) || "";
  if (activeAccountKey.trim()) {
    return activeAccountKey.trim();
  }

  const accountParts = await AsyncStorage.multiGet(["phoneNumber", "dob"]);
  const phoneNumber = accountParts[0]?.[1]?.trim() || "";
  const dob = accountParts[1]?.[1]?.trim() || "";
  if (!phoneNumber || !dob) {
    return "";
  }

  return `${phoneNumber}|${dob}`;
}

async function migrateLegacyProgressData(accountKey: string): Promise<void> {
  const migrationDone = await AsyncStorage.getItem(legacyMigrationFlagKey);
  if (migrationDone === "true") return;

  const allKeys = await AsyncStorage.getAllKeys();
  const scopedPrefixes = [
    `aaradhana${storageSeparator}${accountKey}${storageSeparator}`,
    `points${storageSeparator}${accountKey}${storageSeparator}`,
    `submitted${storageSeparator}${accountKey}${storageSeparator}`,
  ];
  const hasScopedData = allKeys.some((key) =>
    scopedPrefixes.some((prefix) => key.startsWith(prefix)),
  );
  const legacyKeys = allKeys.filter(
    (key) =>
      key.startsWith("aaradhana-") ||
      key.startsWith("points-") ||
      key.startsWith("submitted-"),
  );
  if (legacyKeys.length === 0) {
    await AsyncStorage.setItem(legacyMigrationFlagKey, "true");
    return;
  }

  if (hasScopedData) {
    await AsyncStorage.multiRemove(legacyKeys);
    await AsyncStorage.setItem(legacyMigrationFlagKey, "true");
    return;
  }

  const legacyEntries = await AsyncStorage.multiGet(legacyKeys);
  const migratedEntries: [string, string][] = [];

  legacyEntries.forEach(([legacyKey, value]) => {
    if (value === null) return;

    if (legacyKey.startsWith("aaradhana-")) {
      const dateKey = legacyKey.replace("aaradhana-", "");
      migratedEntries.push([
        getScopedProgressKey("aaradhana", accountKey, dateKey),
        value,
      ]);
      return;
    }

    if (legacyKey.startsWith("points-")) {
      const dateKey = legacyKey.replace("points-", "");
      migratedEntries.push([getScopedProgressKey("points", accountKey, dateKey), value]);
      return;
    }

    if (legacyKey.startsWith("submitted-")) {
      const dateKey = legacyKey.replace("submitted-", "");
      migratedEntries.push([
        getScopedProgressKey("submitted", accountKey, dateKey),
        value,
      ]);
    }
  });

  if (migratedEntries.length > 0) {
    await AsyncStorage.multiSet(migratedEntries);
  }
  await AsyncStorage.multiRemove(legacyKeys);
  await AsyncStorage.setItem(legacyMigrationFlagKey, "true");
}

export default function HomeScreen() {
  const router = useRouter();
  const [showMenu, setShowMenu] = useState(false);
  const [name, setName] = useState("");
  const [hotiNo, setHotiNo] = useState("");
  const [accountKey, setAccountKey] = useState("");
  const [checked, setChecked] = useState<{ [key: string]: boolean }>({});
  const [points, setPoints] = useState(0);
  const [isSubmittedForDate, setIsSubmittedForDate] = useState(false);

  const todayKey = getLocalDateKey(); // YYYY-MM-DD (local timezone)
  const [selectedDate, setSelectedDate] = useState(todayKey);
  const [showCalendar, setShowCalendar] = useState(false);
  const [calendarMonth, setCalendarMonth] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1);
  });

  const calculatePoints = (items: { [key: string]: boolean }) =>
    NIYAM_LIST.reduce((sum, item) => {
      return sum + (items[item.key] ? item.points : 0);
    }, 0);

  const isWithinEditableWindow = (dateKey: string) => {
    const selected = new Date(`${dateKey}T00:00:00`);
    const today = new Date(`${todayKey}T00:00:00`);
    const diffMs = today.getTime() - selected.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= 10;
  };

  const formatDisplayDate = (dateKey: string) => {
    const [year, month, day] = dateKey.split("-");
    return `${day}-${month}-${year}`;
  };

  const formatDateKey = (year: number, month: number, day: number) => {
    const mm = String(month).padStart(2, "0");
    const dd = String(day).padStart(2, "0");
    return `${year}-${mm}-${dd}`;
  };

  const getMonthLabel = (year: number, monthIndex: number) => {
    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];
    return `${monthNames[monthIndex]} ${year}`;
  };

  const loadChecklistForDate = async (dateKey: string, currentAccountKey: string) => {
    const checklistKey = getScopedProgressKey("aaradhana", currentAccountKey, dateKey);
    const pointsKey = getScopedProgressKey("points", currentAccountKey, dateKey);
    const submittedKey = getScopedProgressKey("submitted", currentAccountKey, dateKey);

    const savedChecklist = await AsyncStorage.getItem(checklistKey);
    const parsedChecklist = savedChecklist
      ? (JSON.parse(savedChecklist) as { [key: string]: boolean })
      : {};
    setChecked(parsedChecklist);

    const savedPoints = await AsyncStorage.getItem(pointsKey);
    if (savedPoints) {
      setPoints(Number(savedPoints) || 0);
    } else {
      const calculatedPoints = calculatePoints(parsedChecklist);
      setPoints(calculatedPoints);
      await AsyncStorage.setItem(pointsKey, String(calculatedPoints));
    }

    const submittedFlag = await AsyncStorage.getItem(submittedKey);
    setIsSubmittedForDate(submittedFlag === "true");
  };

  useEffect(() => {
    const loadData = async () => {
      const savedName = await AsyncStorage.getItem("userName");
      const savedHoti =
        (await AsyncStorage.getItem("villageCode")) ||
        (await AsyncStorage.getItem("hotiNo"));
      const resolvedAccountKey = await getAccountKeyFromStorage();

      if (!savedName || !savedHoti || !resolvedAccountKey) {
        router.replace("/login");
        return;
      }

      await migrateLegacyProgressData(resolvedAccountKey);
      setName(savedName);
      setHotiNo(savedHoti);
      setAccountKey(resolvedAccountKey);
      await loadChecklistForDate(selectedDate, resolvedAccountKey);
    };

    loadData();
  }, []);

  useEffect(() => {
    const loadForSelectedDate = async () => {
      if (!accountKey) return;
      await loadChecklistForDate(selectedDate, accountKey);
    };
    loadForSelectedDate();
  }, [selectedDate, accountKey]);

  useEffect(() => {
    const [year, month] = selectedDate.split("-").map(Number);
    setCalendarMonth(new Date(year, month - 1, 1));
  }, [selectedDate]);

  useFocusEffect(
    useCallback(() => {
      const resetToToday = async () => {
        if (!accountKey) return;
        const currentToday = getLocalDateKey();
        setSelectedDate(currentToday);
        setShowCalendar(false);
        await loadChecklistForDate(currentToday, accountKey);
      };
      resetToToday();
    }, [accountKey]),
  );

  const toggleItem = async (key: string) => {
    if (!isWithinEditableWindow(selectedDate)) {
      Alert.alert(
        "Date locked",
        "You can submit/edit only within 10 days from that date.",
      );
      return;
    }

    if (isSubmittedForDate) {
      Alert.alert(
        "Already submitted",
        "Details for this date are locked and cannot be changed.",
      );
      return;
    }

    const updated = { ...checked, [key]: !checked[key] };
    const updatedPoints = calculatePoints(updated);
    setChecked(updated);
    setPoints(updatedPoints);
    if (!accountKey) return;
    await AsyncStorage.multiSet([
      [
        getScopedProgressKey("aaradhana", accountKey, selectedDate),
        JSON.stringify(updated),
      ],
      [getScopedProgressKey("points", accountKey, selectedDate), String(updatedPoints)],
    ]);
    try {
      await upsertCloudProgress({
        accountKey,
        dateKey: selectedDate,
        checklist: updated,
        points: updatedPoints,
        submitted: isSubmittedForDate,
      });
    } catch {
      // Keep local progress working even if cloud sync fails.
    }
  };

  const submitDate = async () => {
    if (!isWithinEditableWindow(selectedDate)) {
      Alert.alert(
        "Date locked",
        "You can submit/edit only within 10 days from that date.",
      );
      return;
    }

    if (isSubmittedForDate) {
      Alert.alert("Already submitted", "This date is already locked.");
      return;
    }

    if (!accountKey) return;
    await AsyncStorage.setItem(
      getScopedProgressKey("submitted", accountKey, selectedDate),
      "true",
    );
    try {
      await upsertCloudProgress({
        accountKey,
        dateKey: selectedDate,
        checklist: checked,
        points,
        submitted: true,
      });
    } catch {
      // Keep submit flow working even if cloud sync fails.
    }
    setIsSubmittedForDate(true);
    Alert.alert("Submitted", "This date is now locked and cannot be edited.");
  };

  const changeMonth = (offset: number) => {
    const next = new Date(
      calendarMonth.getFullYear(),
      calendarMonth.getMonth() + offset,
      1,
    );
    setCalendarMonth(next);
  };

  const selectDate = (day: number) => {
    const year = calendarMonth.getFullYear();
    const month = calendarMonth.getMonth() + 1;
    const chosenDateKey = formatDateKey(year, month, day);
    if (chosenDateKey > todayKey) {
      return;
    }
    setSelectedDate(chosenDateKey);
    setShowCalendar(false);
  };

  const year = calendarMonth.getFullYear();
  const monthIndex = calendarMonth.getMonth();
  const firstDayOfMonth = new Date(year, monthIndex, 1).getDay();
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
  const weekdayLabels = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  const calendarCells = [
    ...Array.from({ length: firstDayOfMonth }, () => 0),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];

  const logout = async () => {
    await AsyncStorage.multiRemove([
      "firstName",
      "middleName",
      "lastName",
      "gender",
      "userName",
      "dateOfBirth",
      "dob",
      "hotiNo",
      "villageCode",
      "profilePhoto",
      "photoUri",
      "phoneNumber",
      "address",
      "activeAccountKey",
      "adminSession",
      "adminSelectedAccountKey",
    ]);
    router.replace("/login");
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#f8fafc" }} edges={["top"]}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 10, paddingBottom: 24 }}
      >
        <View style={{ position: "relative", marginBottom: 14 }}>
          <Text style={{ fontSize: 22, textAlign: "center", color: "#0f172a" }}>
            સંભવનાથાર્પણ
          </Text>
          <TouchableOpacity
            onPress={() => setShowMenu((prev) => !prev)}
            style={{ position: "absolute", right: 0, top: 0, padding: 4 }}
          >
            <Text style={{ fontSize: 26 }}>☰</Text>
          </TouchableOpacity>
          {showMenu && (
            <View
              style={{
                position: "absolute",
                right: 0,
                top: 34,
                backgroundColor: "#f8fafc",
                borderWidth: 1,
                borderColor: "#ddd",
                borderRadius: 8,
                paddingVertical: 6,
                width: 150,
                zIndex: 10,
              }}
            >
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Home</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)/summary");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Summary</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)/leaderboard");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Leaderboard</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/literature");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Literature Files</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  router.push("/(tabs)/profile");
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Profile</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => {
                  setShowMenu(false);
                  logout();
                }}
                style={{ paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text>Logout</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

      <Text style={{ textAlign: "center", marginBottom: 18 }}>
        Name : {name}
      </Text>

      <Text style={{ marginBottom: 8, fontSize: 16, fontWeight: "600", color: "#0f172a" }}>
        Select Date
      </Text>
      <TouchableOpacity
        onPress={() => setShowCalendar((prev) => !prev)}
        style={{
          borderWidth: 1,
          borderColor: "#cbd5e1",
          paddingVertical: 14,
          borderRadius: 14,
          marginBottom: 12,
          backgroundColor: "#f8fafc",
        }}
      >
        <Text style={{ textAlign: "center", fontSize: 19, color: "#0f172a", fontWeight: "600" }}>
          {formatDisplayDate(selectedDate)}
        </Text>
      </TouchableOpacity>

      {showCalendar && (
        <View
          style={{
            borderWidth: 1,
            borderColor: "#dbe3ee",
            borderRadius: 14,
            padding: 12,
            marginBottom: 20,
            backgroundColor: "#f8fafc",
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 10,
            }}
          >
            <TouchableOpacity onPress={() => changeMonth(-1)}>
              <Text style={{ fontSize: 18 }}>{"<"}</Text>
            </TouchableOpacity>
            <Text>{getMonthLabel(year, monthIndex)}</Text>
            <TouchableOpacity onPress={() => changeMonth(1)}>
              <Text style={{ fontSize: 18 }}>{">"}</Text>
            </TouchableOpacity>
          </View>

          <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
            {weekdayLabels.map((label) => (
              <Text
                key={label}
                style={{
                  width: "14.28%",
                  textAlign: "center",
                  marginBottom: 6,
                }}
              >
                {label}
              </Text>
            ))}
            {calendarCells.map((day, index) => {
              if (day === 0) {
                return (
                  <View
                    key={`empty-${index}`}
                    style={{ width: "14.28%", height: 34 }}
                  />
                );
              }

              const dateKey = formatDateKey(year, monthIndex + 1, day);
              const isFuture = dateKey > todayKey;
              const isSelected = dateKey === selectedDate;

              return (
                <TouchableOpacity
                  key={dateKey}
                  onPress={() => selectDate(day)}
                  disabled={isFuture}
                  style={{
                    width: "14.28%",
                    height: 34,
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: isSelected ? "#000" : "transparent",
                    borderRadius: 6,
                    opacity: isFuture ? 0.3 : 1,
                  }}
                >
                  <Text style={{ color: isSelected ? "#fff" : "#000" }}>
                    {day}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      )}

      <View
        style={{
          borderWidth: 1,
          borderColor: "#dbe3ee",
          borderRadius: 14,
          paddingVertical: 14,
          paddingHorizontal: 12,
          marginBottom: 16,
          backgroundColor: "#f8fafc",
        }}
      >
        <Text style={{ fontSize: 18, fontWeight: "700", color: "#0f172a" }}>
          Date Points : {points}
        </Text>
      </View>

      <Text style={{ fontSize: 24, marginBottom: 12, color: "#0f172a" }}>
        દૈનિક નિયમો (Daily Niyams)
      </Text>

      <View
        style={{
          borderWidth: 1,
          borderColor: "#dbe3ee",
          borderRadius: 12,
          overflow: "hidden",
          marginBottom: 12,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            backgroundColor: "#eef2f9",
            paddingVertical: 10,
            paddingHorizontal: 8,
          }}
        >
          <Text style={{ width: "12%", fontWeight: "700" }}>Sr</Text>
          <Text style={{ width: "52%", fontWeight: "700" }}>Niyam</Text>
          <Text style={{ width: "18%", fontWeight: "700", textAlign: "center" }}>
            Pts
          </Text>
          <Text style={{ width: "18%", fontWeight: "700", textAlign: "center" }}>
            Done
          </Text>
        </View>

        {NIYAM_LIST.map((item, index) => (
          <TouchableOpacity
            key={item.key}
            onPress={() => toggleItem(item.key)}
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 10,
              paddingHorizontal: 8,
              borderTopWidth: 1,
              borderTopColor: "#eef2f9",
            }}
          >
            <Text style={{ width: "12%" }}>{index + 1}</Text>
            <View style={{ width: "52%" }}>
              <Text style={{ fontSize: 16, color: "#0f172a" }}>{item.gu}</Text>
              <Text style={{ fontSize: 11, color: "#6b7280" }}>{item.en}</Text>
            </View>
            <Text style={{ width: "18%", textAlign: "center" }}>{item.points}</Text>
            <View style={{ width: "18%", alignItems: "center" }}>
              <View
                style={{
                  width: 22,
                  height: 22,
                  borderWidth: 1,
                  borderColor: "#ea580c",
                  borderRadius: 5,
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                {checked[item.key] && <Text style={{ fontSize: 14 }}>✓</Text>}
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        onPress={submitDate}
        disabled={isSubmittedForDate}
        style={{
          marginTop: 30,
          backgroundColor: isSubmittedForDate ? "#9ca3af" : "#1e293b",
          padding: 14,
          borderRadius: 14,
        }}
      >
        <Text style={{ color: "#fff", textAlign: "center", fontSize: 18, fontWeight: "600" }}>
          {isSubmittedForDate ? "Submitted" : "Submit"}
        </Text>
      </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

